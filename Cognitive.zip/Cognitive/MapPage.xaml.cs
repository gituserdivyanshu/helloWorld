﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Plugin.Geolocator;
using Xamarin.Forms;
using Xamarin.Forms.Maps;

namespace Cognitive
{
    public partial class MapPage : ContentPage
    {
        public MapPage()
        {
            InitializeComponent();
            MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(17, 71), Distance.FromMiles(1)));
            GetPosition();
        }

        public async void GetPosition()
        {
            var locator = CrossGeolocator.Current;
            locator.DesiredAccuracy = 100;
            var position = await locator.GetPositionAsync();
            var lat = position.Latitude;
            var longt = position.Longitude;
        }

    }
}
