﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.ProjectOxford.Vision;
using Microsoft.ProjectOxford.Vision.Contract;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Xamarin.Forms;

namespace Cognitive
{
    public partial class MyPage : ContentPage
    {
        public MyPage()
        {
            InitializeComponent();
        }

        private async Task<AnalysisResult> GetImageDescription(Stream imageStream)
        {
            VisionServiceClient visionClient = new VisionServiceClient("4cf8a14a1e1d49838db0d847193bb2cf","https://westcentralus.api.cognitive.microsoft.com/vision/v1.0");
            VisualFeature[] features = { VisualFeature.Tags };
            return await visionClient.AnalyzeImageAsync(imageStream, features.ToList(), null);
        }

        private async Task SelectPicture()
        {
            if(CrossMedia.Current.IsPickPhotoSupported)
            {
                var image = await CrossMedia.Current.PickPhotoAsync();
                MyImage.Source = ImageSource.FromStream(() =>
                {
                    return image.GetStream();
                                
                });
            
                MyActivityIndicator.IsRunning = true;
                try
                {
                    var result = await GetImageDescription(image.GetStream());
                    foreach(var tag in result.Tags)
                    {
                        MyLabel.Text = MyLabel.Text + tag.Name + "\n";
                    }
                }
                catch(ClientException ex)
                {
                    MyLabel.Text = ex.Message;
                }

                MyActivityIndicator.IsRunning = false;
            }
        }



        async void Handle_Click(object sender, EventArgs e)
        {
            await SelectPicture();
        }

        async void Handle_Click1(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MapPage());
        }


        private async void CameraButton_Clicked(object sender, EventArgs e)
        {
            var photo = await Plugin.Media.CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions() { });

            if (photo != null)
            {
                PhotoImage.Source = ImageSource.FromStream(() => { return photo.GetStream(); });

                MyActivityIndicator.IsRunning = true;
                try
                {
                    var result = await GetImageDescription(photo.GetStream());
                    foreach (var tag in result.Tags)
                    {
                        MyLabel.Text = MyLabel.Text + tag.Name + "\n";
                    }
                }
                catch (ClientException ex)
                {
                    MyLabel.Text = ex.Message;
                }

                MyActivityIndicator.IsRunning = false;
            }
        }
    }
}
